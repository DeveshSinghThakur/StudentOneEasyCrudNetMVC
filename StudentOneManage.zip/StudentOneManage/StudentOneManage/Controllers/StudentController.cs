﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StudentOneManage.Db;
namespace StudentOneManage.Controllers
{
    public class StudentController : ApiController
    {

     

        // GET api/values
        [HttpGet]
        public IEnumerable<StudentModel> Get()
        {
            DBStudentConnect db = new DBStudentConnect();
           return db.GetStudents();

        }

        // GET api/values/5
        [HttpGet]
        public StudentModel Get(int id)
        {
            DBStudentConnect db = new DBStudentConnect();
            return db.GetStudent(id);
        }

        // POST api/values
        [HttpPost]
        public bool InertStudent([FromBody]StudentModel student)
        {
            DBStudentConnect db = new DBStudentConnect();
            return db.InsertStudent(student);
        }

        // PUT api/values/5
        [HttpPost]
        public bool UpdateStudent([FromBody]StudentModel student)
        {
            DBStudentConnect db = new DBStudentConnect();
            return db.UpdateStudent(student);

        }

        // DELETE api/values/5
        [HttpGet]
        public bool DeleteStudent(int id)
        {
            DBStudentConnect db = new DBStudentConnect();
            return db.DeleteStudent(id);
        }
    }
}