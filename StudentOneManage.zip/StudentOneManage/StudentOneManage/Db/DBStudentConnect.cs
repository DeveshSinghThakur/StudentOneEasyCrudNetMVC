﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
namespace StudentOneManage.Db
{
    public class DBStudentConnect
    {

        public string ConStr = "";
        public DBStudentConnect()
        {

            ConStr = "Data Source=DEV-PC\\SQLEXPRESS;Initial Catalog=studentone;Integrated Security=True";
        }



        //select all
        public IEnumerable<StudentModel> GetStudents()
        {

            SqlConnection con = null;
            SqlCommand cmd = null;
            List<StudentModel> students = new List<StudentModel>();
            try
            {
                con = new SqlConnection(ConStr);
                con.Open();
                cmd = new SqlCommand("GetStudents", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        StudentModel student = new StudentModel();
                        student.Id = Convert.ToInt32(dr["Id"].ToString());
                        student.Name = dr["Name"].ToString();
                        student.MobileNo = dr["MobileNo"].ToString();
                        students.Add(student);
                    }
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con = null;
                cmd = null;
            }

            return students;
        }

        //select one
        public StudentModel GetStudent(int id)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            StudentModel student = new StudentModel();
            try
            {
                con = new SqlConnection(ConStr);
                con.Open();
                cmd = new SqlCommand("GetStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id",id);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {

                        student.Id = Convert.ToInt32(dr["Id"].ToString());
                        student.Name = dr["Name"].ToString();
                        student.MobileNo = dr["MobileNo"].ToString();

                    }
                }

            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con = null;
                cmd = null;
            }

            return student;
        }



        //insert
        public bool InsertStudent(StudentModel student)
        {
            bool Success = false;

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                con = new SqlConnection(ConStr);
                con.Open();
                cmd = new SqlCommand("InsertStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", student.Name);
                cmd.Parameters.AddWithValue("@MobileNo", student.MobileNo);
                
                cmd.ExecuteNonQuery();

                Success = true;
            }
            catch (Exception ex)
            {
                Success = false;

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con = null;
                cmd = null;
            }

            return Success;
        }

        //update
        public bool UpdateStudent(StudentModel student)
        {

            bool Success = false;

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                con = new SqlConnection(ConStr);
                con.Open();
                cmd = new SqlCommand("UpdateStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", student.Id);
                cmd.Parameters.AddWithValue("@Name", student.Name);
                cmd.Parameters.AddWithValue("@MobileNo", student.MobileNo);
                
                cmd.ExecuteNonQuery();

                Success = true;
            }
            catch (Exception ex)
            {
                Success = false;

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con = null;
                cmd = null;
            }

            return Success;
        }

        //delete

        public bool DeleteStudent(int id)
        {
            bool Success = false;

            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                con = new SqlConnection(ConStr);
                con.Open();
                cmd = new SqlCommand("DeleteStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
          

                cmd.ExecuteNonQuery();

                Success = true;
            }
            catch (Exception ex)
            {
                Success = false;

            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con = null;
                cmd = null;
            }

            return Success;

        }
    }
}