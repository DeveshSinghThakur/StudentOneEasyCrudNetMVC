﻿
function getStudents()
{

    var path = getPath() + "/api/Student/Get";
    var studentHtml = "";
    $.get(path, function (data) {
    
        $.each(data, function (index, student) {
            studentHtml += "<tr>";
            studentHtml += "<td>"+student.Id+"</td>";
            studentHtml += "<td>"+student.Name+"</td>";
            studentHtml += "<td>"+student.MobileNo+"</td>";
            studentHtml += '<td>  <input type="button" value="Edit" studentid=' + student.Id + '  onclick="goToEditPage(this)"/></td>';
            studentHtml += '<td>  <input type="button" value="Delete" studentid=' + student.Id + '   onclick="deleteStudent(this)"/></td>';
            studentHtml += "</tr>";
        
        })
  

        //bind to table
        $("#studentBodyContent").html(studentHtml);

    });

}

function getStudent()
{
    var id = $("#txtId").val();
    var path = getPath() + "/api/Student/Get/" + id;
    $.get(path, function (data) {

        $("#txtId").val(data.Id);
        $("#txtName").val(data.Name);
        $("#txtMobileNo").val(data.MobileNo);
    });
}

function GoToInsertPage()
{

    window.location=getPath()+"/home/insert";
}

function insertStudent()
{
    var data = {};
    data.Name=$("#txtName").val();
    data.MobileNo=$("#txtMobileNo").val();


    if(data.Name.trim().length>0&&data.MobileNo.trim().length>0)
    {

        var path = getPath() + "/api/Student/InertStudent";
        $.post(path,data, function (data) {

            alert("Inserted  Succesfully..");
            gotoHomePage();
        });
    }
    else
    {
        alert("Please Enter All Data...");
    }
}
function goToEditPage(obj)
{

    var id = obj.getAttribute("studentid");
    window.location = getPath() + "/home/update/" + id;


}

function updateStudent()
{

    var data = {};
    data.Id=$("#txtId").val();
    data.Name=$("#txtName").val();
    data.MobileNo=$("#txtMobileNo").val();
    if(data.Name.trim().length>0&&data.MobileNo.trim().length>0)
    {
        var path = getPath() + "/api/Student/UpdateStudent";
        $.post(path,data, function (data) {
            alert("Updated  Succesfully..");
            gotoHomePage();
        });
    }
    else{
        alert("Please Enter All Data...");
    }

}
function deleteStudent(obj)
{
    var id = obj.getAttribute("studentid");
    var path = getPath() + "/api/Student/DeleteStudent/" + id;
    $.get(path, function (data) {
        alert("Deleted  Succesfully..");
        gotoHomePage();
    });

}

function gotoHomePage()
{

    window.location=getPath()+"/home/index";

}

function getPath()
{
   return window.location.origin;
}






