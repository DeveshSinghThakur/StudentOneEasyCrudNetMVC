create database studentone

use studentone

create table Student
(
Id int identity(1,1),
Name varchar(100),
MobileNo varchar(15)unique
)

--selects
Create procedure GetStudents
as
begin
Select ID,Name,mobileNo from student
end
---select
Create procedure GetStudent (@id int)
as
begin
Select ID,Name,mobileNo from student where Id=@id
end
--insert
Create procedure InsertStudent (@Name varchar(100),@MobileNo varchar(15))
as
begin
insert into student(name,MobileNo) values(@Name,@MobileNo)
end

--update
create procedure UpdateStudent (@id int,@Name varchar(100),@MobileNo varchar(15))
as
begin
update student 
set Name=@Name,
MobileNo=@MobileNo
where Id=@id
end

--delete
Create procedure DeleteStudent (@id int)
as
begin
delete from student where Id=@id
end





-- exec GetStudents







