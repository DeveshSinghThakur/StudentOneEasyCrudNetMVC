﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentOneManage.Db
{
    public class StudentModel
    {
        public int Id { get; set; }
        public String Name {get;set;}
        public string MobileNo {get; set;}
    }
}